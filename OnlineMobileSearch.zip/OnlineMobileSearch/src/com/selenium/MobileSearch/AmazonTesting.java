package com.selenium.MobileSearch;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.support.ui.Select;



/*
 * [jarFiles includes in Referenced libraries]:
 * 		**Apache POI( bin-4.1.2-20200217 )
 * 		**selenium-java-3.141.59
 */


public class AmazonTesting {//
	
	public static WebDriver driver;
	public static String baseUrl;
	public static String searchText;
	public static String checkText;
	public static WebElement dropDown;
	public static List<WebElement> oSize;
	public static String optionName;
	public static String sValue;
	
	public void loadDriver() throws Exception  {//read the properties file
		Properties props = new Properties();
		
		String driverkey = ""; 
		String driverval = "";

InputStream readFile=null;
   try {	
	     readFile=new FileInputStream("DriverProperties.properties");
			props.load(readFile);
			
			 driverkey = props.getProperty("driverkey");
			 driverval = props.getProperty("driverval");
			
			baseUrl = props.getProperty("baseurl");
			searchText=props.getProperty("searchText");
			optionName=props.getProperty("optionName");
			
			System.setProperty(driverkey, driverval);
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		
		if(driverval.contains("chrome")) {
			ChromeOptions co= new ChromeOptions();
						
			co.addArguments("--disable-notifications");//add args to disable browser notifications to chrome
			//co.addArguments("disable-infobars");
			
			//to disable the infobar message to chrome
			co.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
			co.setExperimentalOption("useAutomationExtension",false);
			driver = new ChromeDriver(co);
		}
		else if( driverval.contains("gecko") ) {
			FirefoxOptions fo = new FirefoxOptions();
			
			fo.addPreference("dom.webnotifications.enabled", false);//add preferences to disable browser notifications in firefox
			
			driver = new FirefoxDriver(fo);
			
		}
		
		else {
			throw new Exception("Web Driver not supported");
		}
		
		driver.manage().window().maximize();// to maximize the window
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);// applying Implicitly Wait
		
	}
	private void getURL() {//navigated to  the given URL="https://www.amazon.in/"
		driver.get(baseUrl);
	}

	private void quitDriver() {//quit the browser
		driver.quit();
	}
	
	private void productSearch() {
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys(searchText);//Enter the search text in search bar
		driver.findElement(By.xpath("//input[@id=\"nav-search-submit-button\"]")).click();//click on search button
	}
	private void getText() {
		checkText = driver.findElement(By.xpath("//*[@id=\"search\"]/span/div/span/h1/div/div[1]/div/div/span[1]")).getText();//the get display text
	   System.out.println("The search Result is: "+checkText+" \"" + searchText+"\"");//to print display text
	}
	
	private void validString() {
//to valid the text
		Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"search\"]/span/div/span/h1/div/div[1]/div/div/span[1]")).getText(),checkText);
		   System.out.println("Validate the String Sucessfully");//sucessfully validate message shown

	}
	
	private void selectOptionInDropDown() {
		//select the proper Drop and Down value
	dropDown=driver.findElement(By.xpath("//select[@name='s']"));	
	Select select=new Select(dropDown);
	oSize=select.getOptions();
	int listSize=oSize.size();
	for(int i=0;i<listSize;i++)
	{
		 sValue=select.getOptions().get(i).getText();
		if(sValue.equals(optionName)) {
			select.selectByIndex(i);
			break;
		}
	}
	   System.out.println( optionName+" is selected from DropDown.");

	}
	
	private void validateSelectOption() {
		//to valid the drop down value correctly selected or not
	String chooseOption=driver.findElement(By.xpath("//*[@class=\"a-button-text a-declarative\"]/span[2]")).getText();
	Assert.assertEquals(chooseOption,sValue);
	  System.out.println( sValue+" is verified and got selected correctly");

	}
	
	
	
	
	
public static void main(String[] args) {
		
		AmazonTesting obj=new AmazonTesting();
		//calling all the method in main class
		try {
			obj.loadDriver(); 
			obj.getURL();
			obj.productSearch();
			obj.getText();
			obj.validString();
			obj.selectOptionInDropDown();
			obj.validateSelectOption();
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			obj.quitDriver();
		}

   }

}
