package com.selenium.PropertiesFile;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Properties;

public class WritePropertiesFile {
	public static void main(String[] args) {
		
	Properties props = new Properties();
OutputStream writeFile=null;
try {
	writeFile=new FileOutputStream("DriverProperties.properties");
	
	props.setProperty("driverkey", "webdriver.chrome.driver");
	props.setProperty("driverval", "E:\\COGNIZANT TRAINING\\JAVA\\OnlineMobileSearch\\drivers\\chromedriver.exe");
	
	/*props.setProperty("driverkey", "webdriver.gecko.driver");
	props.setProperty("driverval", "E:\\COGNIZANT TRAINING\\JAVA\\OnlineMobileSearch\\drivers\\geckodriver.exe");
	*/
	
	props.setProperty("baseurl", "https://www.amazon.in/");
	props.setProperty("searchText", "mobile smartphones under 30000");
	props.setProperty("optionName", "Newest Arrivals");
	
	props.store(writeFile, "Web Drivers Properties");
	System.out.println("Successfully Created Properties File.");
}catch (FileNotFoundException e) {
	e.printStackTrace();
} catch (IOException e) {
	e.printStackTrace();
}finally {
	if(writeFile!=null) {
	try {
		writeFile.close();
	}catch(IOException e) {
		e.printStackTrace();
	}

}
}
}
}
